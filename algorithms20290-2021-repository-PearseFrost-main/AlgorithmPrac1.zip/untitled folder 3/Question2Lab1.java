
public class Question2Lab1 {
    public static int option2(int a, int b) {
        int res = 0;
        while (b > 0) {
            if (b % 2 != 0) {
                res = res + a;
            }
            a <<= 1;
            b >>>= 1;
        }
        return res;
    }


    public static void main(String[] args) {
        System.out.println(option2(736, 6523));
        long start=System.nanoTime();
        long finish=System.nanoTime();
        long timeElapsed=finish - start;
        System.out.println(timeElapsed+" nano seconds");
    }
}






