import org.omg.CORBA.PUBLIC_MEMBER;

public class Practical8 {
    public static final int ALPHABET_SIZE=26;//Sets alphabet size to 26

    public static class TrieNode {//class for trie node
        TrieNode[] children = new TrieNode[ALPHABET_SIZE];
        boolean isEndOfWord;//Is true when it represents a leaf node

        TrieNode() {
            isEndOfWord = false;
            for (int i = 0; i < ALPHABET_SIZE; i++) {
                children[i] = null;
            }
        }
    }
        public static TrieNode root;

   public static void insert(String key){//Function to insert a key into trie
       //If node is not present in trie

        TrieNode trie1=root;//Sets the trie1 node as the root node

        for (int lvl=0;lvl<key.length();lvl++) {
           int index = key.charAt(lvl) - 'a';
            if (trie1.children[index] == null) {
                trie1.children[index] = new TrieNode();
            }
                trie1 = trie1.children[index];

        }
            trie1.isEndOfWord=true;
   }
   public static boolean search(String key){//Searches for key and returns
       //true if present and false otherwise

       TrieNode trie1=root;
       for (int lvl=0;lvl<key.length();lvl++){
           int index=key.charAt(lvl)-'a';
           if(trie1.children[index]==null){
               return false;
           }
           trie1=trie1.children[index];
       }
       return (trie1!=null&&trie1.isEndOfWord);
   }
    public static void main(String args[])
    {
        // Input keys (use only 'a' through 'z' and lower case)
        String keys[] = {"bank","book","bar","bring","film","filter","simple","silt"};

        String output[] = {"Not present in trie", "Present in trie"};


        root = new TrieNode();

        // Construct trie
        int i;
        for (i = 0; i < keys.length ; i++)
            insert(keys[i]);

        // Search for different keys
        if(search("simple") == true)
            System.out.println("simple is " + output[1]);
        else System.out.println("simple is " + output[0]);

        if(search("bar") == true)
            System.out.println("bar is " + output[1]);
        else System.out.println("bar is " + output[0]);

        if(search("the") == true)
            System.out.println("the is " + output[1]);
        else System.out.println("the is " + output[0]);

        if(search("film") == true)
            System.out.println("film is " + output[1]);
        else System.out.println("film is " + output[0]);

    }
}
