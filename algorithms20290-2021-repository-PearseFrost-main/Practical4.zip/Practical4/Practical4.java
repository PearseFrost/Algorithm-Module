public class Practical4 {

    //Selection sort method
    public static void selectionSort(int array[]) {//Takes an integer array as parameter
        int size = array.length;//Integer size is equal to the length of the array
        for (int i = 0; i < size - 1; i++) {
            int small = i;//We let the smallest value in array equal i
            for (int j = i + 1; j < size; j++) {
                if (array[j] < array[small]) {//If an integer is smaller than the
                    // original smallest Integer in the array
                    small = j;//makes j equal the smallest integer in the array
                }
            }
            int temp = array[small];
            array[small] = array[i];
            array[i] = temp;
            //Swaps the smallest integer with the first one
        }
        for (int i = 0; i < size; i++) {//For loop to print sorted array
            System.out.print(array[i]);
            System.out.println();
        }
    }



    //Insertion sort method
    public void insertionSort(int array[]) {//Takes integer array as parameter
        int size = array.length;//Integer size is equal to length of array
        for (int i = 1; i < size; i++) {
            int key = array[i];
            int j = i - 1;
            while ((j > -1) && (array[j] > key)) {//Moves integers in array one index up
                //If they are greater than key
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }//Prints sorted array
        for (int i = 0; i < size; i++) {
            System.out.print(array[i]);
            System.out.println();
        }
    }


    public void bogoSort(int[] array) {//Method that actually sorts the array
        while (isSorted(array) == false) {//If array isn't already sorted
            for (int i = 0; i < array.length; i++) {//Swaps two elements at random
                int j =(int)(Math.random() * i);
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        for (int i = 0; i < array.length; i++) {//Prints sorted array
            System.out.print(array[i] + " ");
            System.out.println();
        }
    }
    public boolean isSorted(int[] a)//Method to check if array is already sorted
    {
        for (int i = 1; i < a.length; i++) {
            if (a[i] < a[i - 1]) {//Returns false if not sorted
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {

        int array[]={1,3,5,7};

        Practical4 ob=new Practical4();
        long startTime = System.nanoTime();
        ob.insertionSort(array);
        long elapsedTime = System.nanoTime() - startTime;

        System.out.println("Elapsed time:"
                + elapsedTime);
    }
}
