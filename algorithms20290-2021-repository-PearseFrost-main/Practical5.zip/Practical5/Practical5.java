public class Practical5 {
    int CUTOFF=2;//CUTOFF for enhanced sort
    public void merge(int array[], int lo, int mid, int hi) {//Method to merge two subarrays together
        int l = mid - lo + 1;//Size of first subarray
        int r = hi - mid;//Size of seconds subarray
        int leftArray[] = new int[l];//First subarray created
        int rightArray[] = new int[r];//Second subarray created


        //Copys contents of array into the two subarrays
        for (int i = 0; i < leftArray.length; i++) {
            leftArray[i] = array[lo + i];
        }
        for (int i = 0; i < rightArray.length; i++) {
            rightArray[i] = array[mid + i + 1];
        }
        //Initializes index of two subarrays and actual array
        int leftIndex = 0;
        int rightIndex = 0;
        int mergeIndex = lo;
        //Increments left index or right index depending on which element is bigger
        while (leftIndex < l && rightIndex < r) {
            if (leftArray[leftIndex] <= rightArray[rightIndex]) {
                array[mergeIndex] = leftArray[leftIndex];
                leftIndex++;
            } else {
                array[mergeIndex] = rightArray[rightIndex];
                rightIndex++;
            }
            mergeIndex++;
        }
        //Copys elements left in left array back to original array
        while (leftIndex < l) {
            array[mergeIndex] = leftArray[leftIndex];
            leftIndex++;
            mergeIndex++;
        }
        //Copys elements left in right array back to original array
        while (rightIndex < r) {
            array[mergeIndex] = rightArray[rightIndex];
            rightIndex++;
            mergeIndex++;
        }
    }
        public void sort(int array[],int l,int r){//Recursive function that calls itself to sort
        // two halves of array and then merges them
        if(l<r) {
            int m = l + (-1) / 2;//Mid point
            //Sorts the two halves of the array
            sort(array, l, m);
            sort(array, m + 1, r);
            //Merges them back together
            merge(array, l, m, r);
        }
    }
    public boolean isSorted(int array[]) {//Method to check if array is already sorted
        //For enhanced merge
        for (int i = 0; i < array.length; i++) {
            if (array[i] > array[i + 1]) {
                return false;
            }
        }
            return true;
    }
    public void mergeEnhanced(int array[], int lo, int mid, int hi){//Enhanced merge
        int l = mid - lo + 1;//Size of first subarray
        int r = hi - mid;//Size of seconds subarray
        int leftArray[] = new int[l];//First subarray created
        int rightArray[] = new int[r];//Second subarray created


        while(isSorted(array)==false){//Only runs if array is not already sorted
        //Copys contents of array into the two subarrays
        for (int i = 0; i < leftArray.length; i++) {
            leftArray[i] = array[lo + i];
        }
        for (int i = 0; i < rightArray.length; i++) {
            rightArray[i] = array[mid + i + 1];
        }
        //Initializes index of two subarrays and actual array
        int leftIndex = 0;
        int rightIndex = 0;
        int mergeIndex = lo;
        //Increments left index or right index depending on which element is bigger
        while (leftIndex < l && rightIndex < r) {
            if (leftArray[leftIndex] <= rightArray[rightIndex]) {
                array[mergeIndex] = leftArray[leftIndex];
                leftIndex++;
            } else {
                array[mergeIndex] = rightArray[rightIndex];
                rightIndex++;
            }
            mergeIndex++;
        }
        //Copys elements left in left array back to original array
        while (leftIndex < l) {
            array[mergeIndex] = leftArray[leftIndex];
            leftIndex++;
            mergeIndex++;
        }
        //Copys elements left in right array back to original array
        while (rightIndex < r) {
            array[mergeIndex] = rightArray[rightIndex];
            rightIndex++;
            mergeIndex++;
        }
        }
    }
    public void insertionSort(int array[]) {//Takes integer array as parameter
        int size = array.length;//Integer size is equal to length of array
        for (int i = 1; i < size; i++) {
            int key = array[i];
            int j = i - 1;
            while ((j > -1) && (array[j] > key)) {//Moves integers in array one index up
                //If they are greater than key
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }//Prints sorted array
        for (int i = 0; i < size; i++) {
            System.out.print(array[i]);
            System.out.println();
        }
    }
    public void enhancedSort(int array[],int l,int r){//Recursive function that calls itself to sort
        // two halves of array and then merges them
        if(r<=l+CUTOFF){
            insertionSort(array);
        }
        if(l<r) {
            int m = l + (-1) / 2;//Mid point
            //Sorts the two halves of the array
            enhancedSort(array, l, m);
            enhancedSort(array, m + 1, r);
            //Merges them back together
            merge(array, l, m, r);
        }
    }
    public static void printArray(int array[]){//Function to print the sorted array
        int size=array.length;
        for(int i=0;i<size;i++){
            System.out.println(array[i]);
            System.out.println();
        }
    }

    public static void main(String[] args) {
        int arr[] = {11, 13};

        System.out.println("Given Array");
        printArray(arr);

        Practical5 ob = new Practical5();
        long startTime = System.nanoTime();
        ob.enhancedSort(arr, 0, arr.length - 1);
        long elapsedTime = System.nanoTime() - startTime;
        System.out.println("\nSorted array");
        printArray(arr);
        System.out.println("Elapsed Time: "+elapsedTime+" nano sceonds");
    }
}

