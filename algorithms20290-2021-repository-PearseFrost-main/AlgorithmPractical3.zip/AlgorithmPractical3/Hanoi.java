public class Hanoi {
    public static void towersOfHanoiRecursion(int disk,char source,char dest,char aux){
        //Base Case
        if(disk==0){
            System.out.println("Take disk 1 from rod");
            return;
        }else{//Recursion
            towersOfHanoiRecursion(disk-1,source,dest,aux);
            System.out.println("Move disk"+""+disk+""+"from source rod"+""+source+""+"to dest rod"+dest);
            towersOfHanoiRecursion(disk-1,aux,dest,source);
        }
    }
    public static void towerOfHanoi(int disk,char source,char dest,char aux){

    }

    public static void main(String[] args) {
        int disk=4;
        towersOfHanoiRecursion(disk,'A','B','C');//Sets the number of disks to 4 and names the rods A B AND C
    }
}
