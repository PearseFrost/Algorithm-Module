public class Recursion {
    static int fibonacci(int n) {
        if (n <= 1) {
            return 1;
        }
        int fib = 1;
        int prevFib = 1;

        for (int i = 2; i < n; i++) {
            int temp = fib;
            fib = fib + prevFib;
            prevFib = temp;
        }
        return fib;
    }

    static int recFibonacci(int n) {
        if (n <= 1) {
            return n;
        } else {
            return recFibonacci(n - 1) + recFibonacci(n - 2);
        }
    }

    public static void main(String[] args) {
        int n = 30;
        long start = System.nanoTime();
        System.out.println(fibonacci(n));
        long finish = System.nanoTime();
        long timeElapsed = finish-start;
        System.out.println("elapsed time "+timeElapsed);
    }
}
